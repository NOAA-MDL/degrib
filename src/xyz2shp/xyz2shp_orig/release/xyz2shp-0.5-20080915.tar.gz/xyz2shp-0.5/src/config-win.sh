#!/bin/sh
configure CFLAGS="-O3"
