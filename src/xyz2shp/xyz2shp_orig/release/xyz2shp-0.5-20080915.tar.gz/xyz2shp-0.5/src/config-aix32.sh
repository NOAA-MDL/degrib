#!/bin/sh
configure CC=cc CFLAGS="-O" --with-aixsize=32
