Welcome to the xyz2shp program
Arthur Taylor
8/7/2007

The purpose of this program is to convert a comma delimited xyz file, into
a .shp file.

-----
Usage xyz2shp [OPTION]... [INFILE] [OUTFILE]
Convert a comma delimited ASCII xyz file to a point .shp file.

      --help                 Display this help and exit.
  -V, --version              Output version information and exit.
  -f, --filter               Filter identical lat/lon, keeping the last one seen
-----

