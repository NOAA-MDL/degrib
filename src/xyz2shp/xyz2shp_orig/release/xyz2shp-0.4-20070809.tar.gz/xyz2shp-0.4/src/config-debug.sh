#!/bin/sh
configure CFLAGS="-O3" --with-memwatch --with-debug
