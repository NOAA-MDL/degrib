#!/bin/sh
./simple.tcl maxT024.20041101.txt station.tbl maxT024.20041101.csv
xyz2shp maxT024.20041101.csv maxT024_20041101.shp
